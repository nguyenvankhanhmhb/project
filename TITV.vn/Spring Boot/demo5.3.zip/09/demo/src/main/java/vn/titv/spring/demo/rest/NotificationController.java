package vn.titv.spring.demo.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import vn.titv.spring.demo.service.EmailService;
import vn.titv.spring.demo.service.MessageInterface;

@RestController
public class NotificationController {
    private MessageInterface email;

    @Autowired
    public NotificationController(EmailService email){
        this.email = email;
    }

    @GetMapping("/send-email")
    public String sendEmail(){
        return this.email.sendMessage();
    }

}
