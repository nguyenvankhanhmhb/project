package vn.titv.spring.demo.service;

public interface MessageInterface {
    public String sendMessage();

}
